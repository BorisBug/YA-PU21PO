#ifndef TERMINAL_H
#define TERMINAL_H

#include <stdint.h>

void terminal_init(void);

void terminal_run(void);

#endif /* TERMINAL_H */
