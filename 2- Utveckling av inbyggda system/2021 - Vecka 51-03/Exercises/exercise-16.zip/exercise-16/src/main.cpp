#include <Arduino.h>
#include "terminal.h"

void setup()
{
    terminal_init();
}

void loop()
{
    terminal_run();
}
