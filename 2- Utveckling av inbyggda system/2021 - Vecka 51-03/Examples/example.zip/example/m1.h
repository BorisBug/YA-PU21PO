#ifndef M1_H
#define M1_H

void m1_get_value(void);

#endif
