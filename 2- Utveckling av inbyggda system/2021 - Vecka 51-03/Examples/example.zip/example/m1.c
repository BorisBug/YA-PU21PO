#include "m1.h"

void m1_get_value(void)
{
}
