#ifndef DOUBLE_H
#define DOUBLE_H

void my_free(void *ptr);

#endif /* DOUBLE_H */