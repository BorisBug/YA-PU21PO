#include <stdio.h>
#include "module.h"

int main(void)
{
    printf("Eneter a string: ");
    printf("\nEntered String: %s\n", get_string());

    return 0;
}
