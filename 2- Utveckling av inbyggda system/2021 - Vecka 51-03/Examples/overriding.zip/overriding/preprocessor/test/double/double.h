#ifndef DOUBLE_H
#define DOUBLE_H

#define getchar() get_char()

void set_iobuf(const char *str);

int get_char(void);

#endif /* DOUBLE_H */
