#ifndef MODULE_H
#define MODULE_H

char *get_string(void);

#endif
