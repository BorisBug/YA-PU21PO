#ifndef DEPENDENCY_H
#define DEPENDENCY_H

void dependency_func(void);

#endif /* DEPENDENCY_H */