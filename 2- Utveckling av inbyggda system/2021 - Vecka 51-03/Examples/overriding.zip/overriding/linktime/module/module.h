#ifndef MODULE_H
#define MODULE_H

void module_func(void);

#endif /* MODULE_H */