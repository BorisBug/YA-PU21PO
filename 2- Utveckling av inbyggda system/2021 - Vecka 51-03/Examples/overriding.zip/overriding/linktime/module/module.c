#include "module.h"
#include "dependency.h"

void module_func(void)
{
    dependency_func();
}
