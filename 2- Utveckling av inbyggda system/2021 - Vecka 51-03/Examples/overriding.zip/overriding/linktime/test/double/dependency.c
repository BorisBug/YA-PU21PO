#include <stdio.h>
#include "dependency.h"

void dependency_func(void)
{
    printf("The fake function.\n");
}
