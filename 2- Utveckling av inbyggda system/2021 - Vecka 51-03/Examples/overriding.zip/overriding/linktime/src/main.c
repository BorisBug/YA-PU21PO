#include "module.h"

int main(void)
{
    module_func();

    return 0;
}
