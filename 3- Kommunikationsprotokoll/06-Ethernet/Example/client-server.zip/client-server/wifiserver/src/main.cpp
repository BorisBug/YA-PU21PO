#include <WiFi.h>
#include <Arduino.h>
#include <IPAddress.h>
#include <WiFiServer.h>
#include <WiFiClient.h>

#define SSID "MaxPlus"
#define PASSWORD "SV21TRC3556"

#define PORT (12345U)
#define BUFFER_SIZE (64U)

static WiFiServer server;

void setup()
{
    Serial.begin(9600);
    delay(3000);

    WiFi.begin(SSID, PASSWORD);
    while (WL_CONNECTED != WiFi.status())
    {
        Serial.print(".");
        delay(1000);
    }

    Serial.print("\nIP Address: ");
    Serial.println(WiFi.localIP());

    server.begin(PORT);
}

void loop()
{
    WiFiClient client = server.available();

    if (client && client.connected())
    {
        // Wait on receiving data from the client
        while (!client.available())
        {
            ;
        }

        // Read the received data
        uint8_t buffer[BUFFER_SIZE] = {0};
        uint8_t length = client.read(buffer, BUFFER_SIZE);

        // Convert the data to uppercase
        for (uint8_t i = 0; i < length; i++)
        {
            buffer[i] = toupper(buffer[i]);
        }

        // Send the data to the client
        client.write(buffer, length);
        client.flush();
    }
}
