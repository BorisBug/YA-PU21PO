#include <time.h>
#include <netdb.h>
#include <stdio.h>
#include <stdint.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define MAX 64U
#define PORT 12345U
#define SERVER "192.168.0.156"

int main(void)
{
    struct sockaddr_in servaddr = {0};

    // Assign IP and PORT
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = inet_addr(SERVER);
    servaddr.sin_port = htons(PORT);

    srand(time(NULL));

    while (1)
    {
        // Create socket and check
        int sockfd = socket(AF_INET, SOCK_STREAM, IPPROTO_IP);
        if (sockfd == -1)
        {
            perror("Failed to create the socket...\n");
            exit(0);
        }

        // Connect to the server
        if (0 != connect(sockfd, (struct sockaddr *)&servaddr, sizeof(servaddr)))
        {
            perror("Connection to the server failed...\n");
            close(sockfd);
            exit(0);
        }

        char buffer[MAX] = {0};
        int len = 1 + rand() % (MAX - 1);

        for (int i = 0; i < len; i++)
        {
            buffer[i] = 'a' + rand() % 26;
        }
        printf("Sent    : %s\n", buffer);

        write(sockfd, buffer, sizeof(buffer)); // Send buffer to the server

        bzero(buffer, sizeof(buffer));

        read(sockfd, buffer, sizeof(buffer)); // Receive data from the server and store it in buffer

        // Close the socket
        close(sockfd);

        printf("Received: %s\n\n", buffer);

        sleep(1);
    }

    return 0;
}