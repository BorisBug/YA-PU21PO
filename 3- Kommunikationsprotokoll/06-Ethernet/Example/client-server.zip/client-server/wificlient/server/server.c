#include <stdio.h>
#include <netdb.h>
#include <ctype.h>
#include <stdint.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define MAX 64U
#define PORT 12345U

int main(void)
{
    struct sockaddr_in servaddr = {0};

    // Create socket and check
    int sockfd = socket(AF_INET, SOCK_STREAM, IPPROTO_IP);
    if (sockfd == -1)
    {
        perror("Failed to create the socket...\n");
        exit(0);
    }

    // Assign IP and PORT
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servaddr.sin_port = htons(PORT);

    // Binding newly created socket to given IP and verification
    if (0 != bind(sockfd, (struct sockaddr *)&servaddr, sizeof(servaddr)))
    {
        perror("Failed to bind the socket...\n");
        close(sockfd);
        exit(0);
    }

    if (0 != listen(sockfd, 1)) // only one connection
    {
        perror("Failed to listen to the port...\n");
        close(sockfd);
        exit(0);
    }

    while (1)
    {
        struct sockaddr_in cli = {0};
        int len = sizeof(cli);

        // Accept and check the connection
        int connfd = accept(sockfd, (struct sockaddr *)&cli, &len);
        if (connfd < 0)
        {
            perror("Failed to accept the connection...\n");
            break;
        }
        else
        {
            printf("Server acccepted the client..\n");
        }

        char buffer[MAX] = {0};

        // Read the message from client and store it in buffer
        read(connfd, buffer, sizeof(buffer));

        for (char *ptr = buffer; *ptr; ptr++)
        {
            *ptr = toupper(*ptr);
        }

        // Send buffer to client
        write(connfd, buffer, sizeof(buffer));

        // Close the connection
        close(connfd);
    }

    // Close the socket
    close(sockfd);

    return 0;
}
