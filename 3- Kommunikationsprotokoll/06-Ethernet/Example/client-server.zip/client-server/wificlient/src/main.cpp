#include <WiFi.h>
#include <Arduino.h>
#include <IPAddress.h>
#include <WiFiClient.h>

#define SSID "MaxPlus"         // The SSID of your wifi
#define PASSWORD "SV21TRC3556" // The password of your wifi

#define PORT (12345U)
#define BUFFER_SIZE (64U)
#define SERVER "192.168.0.188" // Change this to the IP address of the server

typedef struct
{
    uint8_t data[BUFFER_SIZE];
    uint8_t length;
} request_t;

typedef struct
{
    uint8_t data[BUFFER_SIZE];
    uint8_t length;
} response_t;

static WiFiClient client;

static response_t post(request_t *req)
{
    response_t res = {.data = {0}, .length = 0};

    client.connect(SERVER, PORT); // Connect to the server

    if (client.connected())
    {
        // Send the data to the server
        client.write(req->data, req->length);
        client.flush();

        // Read the received data
        res.length = client.readBytes(res.data, BUFFER_SIZE);

        // Close the connection
        client.stop();
    }

    return res;
}

void setup()
{
    Serial.begin(9600);
    while (!Serial)
    {
        delay(100);
    }

    WiFi.begin(SSID, PASSWORD);
    while (WL_CONNECTED != WiFi.status())
    {
        Serial.print(".");
        delay(1000);
    }

    Serial.print("\nIP Address: ");
    Serial.println(WiFi.localIP());

    client.setTimeout(1);
}

void loop()
{
    request_t request = {0};
    request.length = random(1, BUFFER_SIZE);

    Serial.print("\nSent    : ");
    for (uint8_t i = 0; i < request.length; i++)
    {
        request.data[i] = 'a' + random(26);
        Serial.print((char)request.data[i]);
    }
    Serial.println();

    response_t response = post(&request);

    Serial.printf("Received: %s\n", response.data);

    delay(1000);
}
