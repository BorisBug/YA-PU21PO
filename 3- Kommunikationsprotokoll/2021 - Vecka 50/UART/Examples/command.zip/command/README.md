# UART - Command

## Connections

ESP32.........Teensy

GND............GND

TX.............RX1

RX.............TX1
