# ESP32 Provisioning

## SmartConfig

Look at <https://github.com/espressif/arduino-esp32/blob/master/libraries/WiFi/examples/WiFiSmartConfig>

## softAP Provisioning

Look at <https://github.com/espressif/arduino-esp32/tree/master/libraries/WiFiProv>

## BLE Provisioning

Look at <https://github.com/espressif/arduino-esp32/tree/master/libraries/WiFiProv>
