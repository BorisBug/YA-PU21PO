# Bluetooth - UART over BLE

Make a scanner program for ESP32 to scan and find BLE devices and print them to a terminal
