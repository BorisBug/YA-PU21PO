# Bluetooth - UART over BLE

In this program brightness of the builtin LED of ESP32 is be controlled using UART over BLE.
Install nRF Toolbox on your mobile and connect to ESP32 and send a number in the range of 0 and 255.
