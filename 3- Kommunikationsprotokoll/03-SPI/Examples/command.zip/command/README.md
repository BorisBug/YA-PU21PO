# SPI

## Connections

Teensy(Slave) ........... ESP32(Master)

SS(10) .................. SS(33)

MISO(12) ................ MOSI(18)

MOSI(11) ................ MISO(19)

SCK(14) ................. SCK(5)

GND ..................... GND
